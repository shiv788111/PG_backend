import express from "express";

import {
  createComplaint,
  getComplaints,
  resolveComplaint,
} from "./complaints.controller.js";

import { verifyToken } from "../../common/middlewares/auth.middleware.js";

import { allowRoles } from "../../common/middlewares/role.middleware.js";

const router = express.Router();

/*--------------Create Complaint-----------*/

router.post("/create", verifyToken, allowRoles("admin"), createComplaint);

/*--------------Get Complaints-----------*/

router.get("/", verifyToken, allowRoles("admin"), getComplaints);

/*--------------Resolve Complaint-----------*/

router.put("/resolve/:id", verifyToken, allowRoles("admin"), resolveComplaint);

export default router;
