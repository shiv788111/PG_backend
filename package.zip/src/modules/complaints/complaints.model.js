import db from "../../common/config/db.js";

/*--------------Check Tenant Ownership-----------*/

export const checkTenantOwnership = async (tenant_id, user_id) => {
  const query = `
      SELECT tenants.*
      FROM tenants

      JOIN branches
      ON branches.branch_id =
      tenants.branch_id

      JOIN properties
      ON properties.property_id =
      branches.property_id

      WHERE tenants.tenant_id = ?
      AND properties.user_id = ?

      LIMIT 1
    `;

  const [results] = await db.query(query, [tenant_id, user_id]);

  return results[0];
};

/*--------------Create Complaint-----------*/

export const createComplaintQuery = async (data) => {
  const query = `
      INSERT INTO complaints
      (
        tenant_id,
        branch_id,
        title,
        description,
        category
      )
      VALUES (?, ?, ?, ?, ?)
    `;

  const [result] = await db.query(query, [
    data.tenant_id,
    data.branch_id,
    data.title,
    data.description,
    data.category,
  ]);

  return result;
};

/*--------------Get Complaints-----------*/

export const getComplaintsQuery = async (user_id) => {
  const query = `
    SELECT
      complaints.complaint_id,
      complaints.tenant_id,

      CONCAT(
        tenants.first_name,
        ' ',
        tenants.last_name
      ) AS tenant_name,

      rooms.name AS room_no,

      complaints.branch_id,

      branches.name AS branch_name,

      complaints.title,
      complaints.description,
      complaints.category,
      complaints.status,
      complaints.created_at,
      complaints.updated_at

    FROM complaints

    JOIN branches
    ON branches.branch_id =
    complaints.branch_id

    JOIN properties
    ON properties.property_id =
    branches.property_id

    LEFT JOIN tenants
    ON tenants.tenant_id =
    complaints.tenant_id

    LEFT JOIN beds
    ON beds.bed_id =
    tenants.bed_id

    LEFT JOIN rooms
    ON rooms.room_id =
    beds.room_id

    WHERE properties.user_id = ?

    AND complaints.deleted_at IS NULL

    ORDER BY complaints.complaint_id DESC
  `;

  const [results] = await db.query(query, [user_id]);

  return results;
};

/*--------------Check Complaint Ownership-----------*/

export const checkComplaintOwnership = async (complaint_id, user_id) => {
  const query = `
      SELECT complaints.*
      FROM complaints

      JOIN branches
      ON branches.branch_id =
      complaints.branch_id

      JOIN properties
      ON properties.property_id =
      branches.property_id

      WHERE complaints.complaint_id = ?
      AND properties.user_id = ?

      LIMIT 1
    `;

  const [results] = await db.query(query, [complaint_id, user_id]);

  return results[0];
};

/*--------------Resolve Complaint-----------*/

export const resolveComplaintQuery = async (complaint_id) => {
  const query = `
      UPDATE complaints
      SET status = 'resolved'
      WHERE complaint_id = ?
    `;

  const [result] = await db.query(query, [complaint_id]);

  return result;
};
