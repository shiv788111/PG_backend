import {
  checkTenantOwnership,
  createComplaintQuery,
  getComplaintsQuery,
  resolveComplaintQuery,
  checkComplaintOwnership,
} from "./complaints.model.js";

import { createNotificationService } from "../notifications/notifications.service.js";

/*===========================================================================
|--------------------------------------------------------------------------
| CREATE COMPLAINT
|--------------------------------------------------------------------------
===========================================================================*/

export const createComplaint = async (payload, user) => {
  const { tenant_id, branch_id, title, description, category } = payload;

  /*
    |--------------------------------------------------------------------------
    | CHECK TENANT OWNERSHIP
    |--------------------------------------------------------------------------
    */

  const tenant = await checkTenantOwnership(tenant_id, user.user_id);

  if (!tenant) {
    throw new Error("Tenant not found");
  }

  /*
    |--------------------------------------------------------------------------
    | CREATE COMPLAINT
    |--------------------------------------------------------------------------
    */

  const result = await createComplaintQuery({
    tenant_id,
    branch_id,
    title,
    description,
    category,
  });

  /*
    |--------------------------------------------------------------------------
    | NOTIFICATION :
    | Complaint Registered
    |--------------------------------------------------------------------------
    */

  await createNotificationService({
    user_id: 1,
    //  user_id: user.user_id,
    type: "complaint_open",
    title: "Complaint Registered",
    message: "Your complaint registered successfully",
    reference_id: result.insertId,
  });

  return null;
};

/*===========================================================================
|--------------------------------------------------------------------------
| GET COMPLAINTS
|--------------------------------------------------------------------------
===========================================================================*/

export const getComplaints = async (user) => {
  return await getComplaintsQuery(user.user_id);
};

/*===========================================================================
|--------------------------------------------------------------------------
| RESOLVE COMPLAINT
|--------------------------------------------------------------------------
===========================================================================*/

export const resolveComplaint = async (complaint_id, user) => {
  /*
    |--------------------------------------------------------------------------
    | CHECK COMPLAINT OWNERSHIP
    |--------------------------------------------------------------------------
    */

  const complaint = await checkComplaintOwnership(complaint_id, user.user_id);

  if (!complaint) {
    throw new Error("Complaint not found");
  }

  /*
    |--------------------------------------------------------------------------
    | RESOLVE COMPLAINT
    |--------------------------------------------------------------------------
    */

  await resolveComplaintQuery(complaint_id);

  /*
    |--------------------------------------------------------------------------
    | NOTIFICATION :
    | Complaint Resolved
    |--------------------------------------------------------------------------
    */

  await createNotificationService({
    // user_id: 1,
     user_id: user.user_id,
    type: "complaint_solved",
    title: "Complaint Resolved",
    message: "Your complaint resolved successfully",
    reference_id: complaint_id,
  });

  return null;
};
