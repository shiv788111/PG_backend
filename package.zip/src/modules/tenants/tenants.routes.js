import express from "express";

import {
  createTenant,
  getTenants,
  vacateTenant,
} from "./tenants.controller.js";

const router = express.Router();

/*--------------Create Tenant-----------*/

router.post("/create", createTenant);

/*--------------Get Tenants-----------*/

router.get("/", getTenants);

/*--------------Vacate Tenant (jb koi tenant chla jata h to status update ke liye nhi to occupayi show krega always)-----------*/

router.put("/vacate/:id", vacateTenant);

export default router;
